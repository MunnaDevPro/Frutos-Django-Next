# orders/serializers.py
import logging
import traceback
from rest_framework import serializers
from django.db import transaction
from django.contrib.auth import get_user_model
from decimal import Decimal
from .models import (
    Order, OrderItem, OrderUpdate, ShippingMethod, OrderPayment,
    Coupon, ShippingTier, FreeShippingRule
)
from products.models import Product, Color, Size, CategoryMinimumOrderQuantity, Category
from products.serializers import ColorSerializer, SizeSerializer
from users.models import Address

User = get_user_model()
logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════
#  ORDER CREATION SERIALIZERS
# ══════════════════════════════════════════════════════════════════

class OrderItemCreateSerializer(serializers.Serializer):
    """Single item in an order — product is UUID string."""
    product  = serializers.UUIDField()
    quantity = serializers.IntegerField(min_value=1)
    color    = serializers.IntegerField(allow_null=True, required=False)
    size     = serializers.IntegerField(allow_null=True, required=False)

    def validate_product(self, value):
        if not Product.objects.filter(id=value).exists():
            raise serializers.ValidationError("Product does not exist.")
        return value

    def validate_color(self, value):
        if value is not None and not Color.objects.filter(id=value).exists():
            raise serializers.ValidationError("Color does not exist.")
        return value

    def validate_size(self, value):
        if value is not None and not Size.objects.filter(id=value).exists():
            raise serializers.ValidationError("Size does not exist.")
        return value


class OrderCreateSerializer(serializers.Serializer):
    """
    Accepts inline address data from the frontend.
    No shipping_address FK or shipping_method FK required.
    """
    # ── Customer ──────────────────────────────────────────────────
    customer_name  = serializers.CharField(max_length=100)
    customer_email = serializers.EmailField()
    customer_phone = serializers.CharField(max_length=50)

    # ── Inline address ────────────────────────────────────────────
    street_address = serializers.CharField(max_length=255)
    city           = serializers.CharField(max_length=100)
    postcode       = serializers.CharField(max_length=20)

    # ── Delivery ──────────────────────────────────────────────────
    delivery_date       = serializers.CharField(max_length=50,  required=False, allow_blank=True, default='')
    delivery_slot       = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')
    delivery_slot_label = serializers.CharField(max_length=100, required=False, allow_blank=True, default='')

    # ── Payment ───────────────────────────────────────────────────
    payment_method = serializers.CharField(max_length=50, default='cash')

    # ── Coupon ────────────────────────────────────────────────────
    coupon_code = serializers.CharField(max_length=50, required=False, allow_blank=True, default='')

    # ── Items ─────────────────────────────────────────────────────
    items = OrderItemCreateSerializer(many=True)

    def validate_items(self, value):
        if not value:
            raise serializers.ValidationError("At least one item is required.")
        return value

    def create(self, validated_data):
        items_data  = validated_data.pop('items')
        coupon_code = validated_data.pop('coupon_code', '').strip()

        request = self.context.get('request')
        user    = request.user if request and request.user.is_authenticated else None

        with transaction.atomic():
            # ── Build cart ────────────────────────────────────────
            cart_subtotal = Decimal('0.00')
            cart_items    = []

            for item_data in items_data:
                try:
                    product = Product.objects.get(id=item_data['product'])
                except Product.DoesNotExist:
                    raise serializers.ValidationError(
                        f"Product '{item_data['product']}' not found."
                    )
                qty        = item_data['quantity']
                unit_price = product.discount_price if product.discount_price else product.price
                subtotal   = unit_price * qty
                cart_subtotal += subtotal
                cart_items.append({
                    'product':    product,
                    'quantity':   qty,
                    'unit_price': unit_price,
                    'color_id':   item_data.get('color'),
                    'size_id':    item_data.get('size'),
                })

            # ── Wholesale validation ──────────────────────────────
            if user and getattr(user, 'user_type', None) == 'WHOLESALER':
                profile = getattr(user, 'wholesaler_profile', None)
                if profile and getattr(profile, 'approval_status', None) == 'APPROVED':
                    self._validate_wholesale_minimums(cart_items)
                else:
                    raise serializers.ValidationError(
                        "Your wholesaler account is not yet approved."
                    )

            # ── Coupon ────────────────────────────────────────────
            product_discount = Decimal('0.00')
            if coupon_code:
                try:
                    coupon = Coupon.objects.get(code=coupon_code, active=True)
                    is_valid, message = coupon.is_valid_for_cart(
                        [{'quantity': i['quantity']} for i in cart_items],
                        user,
                        cart_subtotal,
                    )
                    if not is_valid:
                        raise serializers.ValidationError(f"Coupon error: {message}")
                    discounts        = coupon.calculate_discount(cart_subtotal)
                    product_discount = Decimal(str(discounts.get('product_discount', 0)))
                except Coupon.DoesNotExist:
                    raise serializers.ValidationError("Invalid coupon code.")

            total_amount = cart_subtotal - product_discount

            # ── Create Order ──────────────────────────────────────
            order = Order.objects.create(
                user                = user,
                customer_name       = validated_data['customer_name'],
                customer_email      = validated_data['customer_email'],
                customer_phone      = validated_data['customer_phone'],
                street_address      = validated_data.get('street_address', ''),
                city                = validated_data.get('city', ''),
                postcode            = validated_data.get('postcode', ''),
                payment_method      = validated_data.get('payment_method', 'cash'),
                delivery_date       = validated_data.get('delivery_date', ''),
                delivery_slot_label = (
                    validated_data.get('delivery_slot_label', '')
                    or validated_data.get('delivery_slot', '')
                ),
                promo_discount      = product_discount,
                cart_subtotal       = cart_subtotal,
                total_amount        = total_amount,
            )

            # ── Create OrderItems ─────────────────────────────────
            for item in cart_items:
                color = None
                size  = None
                if item['color_id']:
                    color = Color.objects.filter(id=item['color_id']).first()
                if item['size_id']:
                    size = Size.objects.filter(id=item['size_id']).first()

                OrderItem.objects.create(
                    order      = order,
                    product    = item['product'],
                    quantity   = item['quantity'],
                    unit_price = item['unit_price'],
                    color      = color,
                    size       = size,
                )

            # ── Order log ─────────────────────────────────────────
            OrderUpdate.objects.create(
                order  = order,
                status = order.status,
                notes  = "Order placed successfully.",
            )

            return order

    def _validate_wholesale_minimums(self, cart_items):
        from collections import defaultdict
        category_quantities = defaultdict(int)
        for item in cart_items:
            product  = item['product']
            category = product.sub_category.category
            category_quantities[category] += item['quantity']

        errors = []
        for category, qty in category_quantities.items():
            try:
                req = CategoryMinimumOrderQuantity.objects.get(category=category)
                if qty < req.minimum_quantity:
                    errors.append(
                        f"'{category.name}' requires minimum {req.minimum_quantity} units "
                        f"(you have {qty})."
                    )
            except CategoryMinimumOrderQuantity.DoesNotExist:
                continue
        if errors:
            raise serializers.ValidationError(" | ".join(errors))


# ══════════════════════════════════════════════════════════════════
#  READ SERIALIZERS
# ══════════════════════════════════════════════════════════════════

class OrderUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model  = OrderUpdate
        fields = ['id', 'status', 'notes', 'timestamp']


class OrderItemReadSerializer(serializers.ModelSerializer):
    product_name  = serializers.CharField(source='product.name',   read_only=True)
    product_image = serializers.SerializerMethodField()
    color_name    = serializers.CharField(source='color.name',     read_only=True)
    size_name     = serializers.CharField(source='size.name',      read_only=True)
    line_total    = serializers.SerializerMethodField()

    class Meta:
        model  = OrderItem
        fields = [
            'id', 'product', 'product_name', 'product_image',
            'color', 'color_name', 'size', 'size_name',
            'quantity', 'unit_price', 'line_total',
        ]

    def get_product_image(self, obj):
        if obj.product and obj.product.thumbnail:
            request = self.context.get('request')
            url     = obj.product.thumbnail.url
            return request.build_absolute_uri(url) if request else url
        return None

    def get_line_total(self, obj):
        return str(obj.quantity * obj.unit_price)


class OrderPaymentReadSerializer(serializers.ModelSerializer):
    payment_method_display = serializers.CharField(
        source='get_payment_method_display', read_only=True
    )

    class Meta:
        model  = OrderPayment
        fields = [
            'admin_account_number', 'sender_number', 'transaction_id',
            'payment_method', 'payment_method_display', 'created_at',
        ]


class OrderReadSerializer(serializers.ModelSerializer):
    items                  = OrderItemReadSerializer(many=True, read_only=True)
    payment                = OrderPaymentReadSerializer(read_only=True)
    updates                = OrderUpdateSerializer(many=True, read_only=True)
    status_display         = serializers.CharField(source='get_status_display',         read_only=True)
    payment_status_display = serializers.CharField(source='get_payment_status_display', read_only=True)

    # Writable fields for PATCH (admin status update)
    status         = serializers.CharField(required=False)
    payment_status = serializers.CharField(required=False)
    tracking_number = serializers.CharField(required=False, allow_blank=True, allow_null=True)

    class Meta:
        model  = Order
        fields = [
            'id', 'order_number', 'total_amount', 'cart_subtotal',
            'status', 'status_display', 'payment_status', 'payment_status_display',
            'customer_name', 'customer_email', 'customer_phone',
            'street_address', 'city', 'postcode',
            'payment_method', 'delivery_date', 'delivery_slot_label',
            'tracking_number',
            'ordered_at', 'items', 'payment', 'updates',
        ]


# ══════════════════════════════════════════════════════════════════
#  PAYMENT CONFIRM SERIALIZER
# ══════════════════════════════════════════════════════════════════

class OrderPaymentCreateSerializer(serializers.Serializer):
    sender_number        = serializers.CharField(max_length=50)
    transaction_id       = serializers.CharField(max_length=100)
    payment_method       = serializers.ChoiceField(choices=OrderPayment.PaymentMethod.choices)
    admin_account_number = serializers.CharField(max_length=50, required=False)

    def validate_transaction_id(self, value):
        if OrderPayment.objects.filter(transaction_id=value).exists():
            raise serializers.ValidationError("Transaction ID already exists.")
        return value


# ══════════════════════════════════════════════════════════════════
#  SHIPPING SERIALIZERS
# ══════════════════════════════════════════════════════════════════

class ShippingTierSerializer(serializers.ModelSerializer):
    pricing_explanation = serializers.SerializerMethodField()
    applicable_range    = serializers.SerializerMethodField()

    class Meta:
        model  = ShippingTier
        fields = [
            'id', 'min_quantity', 'max_quantity', 'min_weight', 'max_weight',
            'pricing_type', 'base_price', 'has_incremental_pricing',
            'increment_per_unit', 'increment_unit_size', 'priority',
            'pricing_explanation', 'applicable_range',
        ]

    def get_pricing_explanation(self, obj):
        if obj.has_incremental_pricing:
            unit = "kg" if obj.pricing_type == 'weight' else "items"
            return f"Base: {obj.base_price} + {obj.increment_per_unit} per {obj.increment_unit_size} {unit}"
        return f"Fixed: {obj.base_price}"

    def get_applicable_range(self, obj):
        if obj.pricing_type == 'weight':
            r = f"{obj.min_weight}kg"
            return r + (f" - {obj.max_weight}kg" if obj.max_weight else "+")
        r = f"{obj.min_quantity}"
        return r + (f" - {obj.max_quantity} items" if obj.max_quantity else "+ items")


class ShippingMethodSerializer(serializers.ModelSerializer):
    title               = serializers.CharField(source='name', read_only=True)
    shipping_tiers      = ShippingTierSerializer(many=True, read_only=True)
    quantity_tiers      = serializers.SerializerMethodField()
    weight_tiers        = serializers.SerializerMethodField()
    shipping_categories = serializers.SerializerMethodField()

    class Meta:
        model  = ShippingMethod
        fields = [
            'id', 'title', 'name', 'description', 'price',
            'delivery_estimated_time', 'max_weight', 'max_quantity',
            'preferred_pricing_type', 'shipping_tiers',
            'quantity_tiers', 'weight_tiers', 'shipping_categories',
        ]

    def get_quantity_tiers(self, obj):
        return ShippingTierSerializer(
            obj.shipping_tiers.filter(pricing_type='quantity'), many=True
        ).data

    def get_weight_tiers(self, obj):
        return ShippingTierSerializer(
            obj.shipping_tiers.filter(pricing_type='weight'), many=True
        ).data

    def get_shipping_categories(self, obj):
        return [
            {'id': c.id, 'name': c.name}
            for c in obj.shipping_categories.all()
        ]

    def to_representation(self, instance):
        rep = super().to_representation(instance)
        rep['quantity_pricing_examples'] = [
            {'quantity': q, 'price': str(instance.get_price_for_quantity(q))}
            for q in [1, 5, 10, 20]
        ]
        rep['weight_pricing_examples'] = [
            {'weight': w, 'price': str(instance.get_price_for_weight(w))}
            for w in [0.5, 1.0, 1.5, 2.0, 3.0]
        ]
        return rep


class ShippingCategorySerializer(serializers.ModelSerializer):
    allowed_shipping_methods = ShippingMethodSerializer(many=True, read_only=True)

    class Meta:
        model  = Category
        fields = ['id', 'name', 'allowed_shipping_methods']


class FreeShippingRuleSerializer(serializers.ModelSerializer):
    applicable_categories = ShippingCategorySerializer(many=True, read_only=True)

    class Meta:
        model  = FreeShippingRule
        fields = [
            'id', 'name', 'threshold_amount', 'applicable_categories',
            'applicable_products', 'active', 'created_at',
        ]


class FreeShippingRuleWriteSerializer(serializers.ModelSerializer):
    applicable_categories = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Category.objects.all(), required=False
    )
    applicable_products = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Product.objects.all(), required=False
    )

    class Meta:
        model  = FreeShippingRule
        fields = ['id', 'name', 'threshold_amount', 'applicable_categories', 'applicable_products', 'active']


# ══════════════════════════════════════════════════════════════════
#  COUPON SERIALIZERS
# ══════════════════════════════════════════════════════════════════
class CouponSerializer(serializers.ModelSerializer):
    type_display             = serializers.CharField(source='get_type_display', read_only=True)
    is_expired               = serializers.SerializerMethodField()
    is_valid_period          = serializers.SerializerMethodField()
    eligible_users_count     = serializers.SerializerMethodField()
    applicable_products_data = serializers.SerializerMethodField()

    class Meta:
        model  = Coupon
        fields = [
            'id', 'code', 'type', 'type_display',
            'discount_type', 'discount_percent', 'discount_amount',
            'min_quantity_required', 'min_cart_total',
            'usage_limit', 'used_count',
            'applicable_products', 'applicable_products_data',
            'active', 'is_expired', 'is_valid_period',
            'eligible_users_count', 'created_at', 'valid_from', 'expires_at',
        ]
        read_only_fields = ['created_at', 'used_count']

    def get_is_expired(self, obj):
        try: return obj.is_expired()
        except: return False

    def get_is_valid_period(self, obj):
        try: return obj.is_valid_period()
        except: return True

    def get_eligible_users_count(self, obj):
        if obj.type == 'USER_SPECIFIC':
            return obj.eligible_users.count()
        return None

    def get_applicable_products_data(self, obj):
        return [{'id': p.id, 'name': p.name} for p in obj.applicable_products.all()]


class CouponValidationSerializer(serializers.Serializer):
    coupon_code = serializers.CharField(max_length=50)
    cart_items  = serializers.ListField(child=serializers.DictField())
    cart_total  = serializers.DecimalField(max_digits=10, decimal_places=2, required=False)
    user_id     = serializers.IntegerField(required=False)


# ══════════════════════════════════════════════════════════════════
#  LEGACY / ADMIN SERIALIZERS
# ══════════════════════════════════════════════════════════════════

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Address
        fields = '__all__'


class OrderItemSerializer(serializers.ModelSerializer):
    product = serializers.StringRelatedField()
    color   = serializers.StringRelatedField()
    size    = serializers.StringRelatedField()

    class Meta:
        model  = OrderItem
        fields = ['id', 'product', 'color', 'size', 'quantity', 'unit_price']


class OrderPaymentSerializer(serializers.ModelSerializer):
    payment_method_display = serializers.CharField(
        source='get_payment_method_display', read_only=True
    )

    class Meta:
        model  = OrderPayment
        fields = [
            'id', 'order', 'admin_account_number', 'sender_number',
            'transaction_id', 'payment_method', 'payment_method_display',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['created_at', 'updated_at']


class ShippingTierWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model  = ShippingTier
        fields = [
            'id', 'shipping_method', 'min_quantity', 'max_quantity',
            'min_weight', 'max_weight', 'pricing_type', 'base_price',
            'has_incremental_pricing', 'increment_per_unit',
            'increment_unit_size', 'priority',
        ]


class ShippingMethodWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model  = ShippingMethod
        fields = [
            'id', 'name', 'description', 'price', 'delivery_estimated_time',
            'max_weight', 'max_quantity', 'preferred_pricing_type', 'is_active',
        ]


class ShippingCategoryWriteSerializer(serializers.ModelSerializer):
    allowed_shipping_methods = serializers.PrimaryKeyRelatedField(
        many=True, queryset=ShippingMethod.objects.all(), required=False
    )

    class Meta:
        model  = Category
        fields = ['id', 'name', 'allowed_shipping_methods']

    def create(self, validated_data):
        methods = validated_data.pop('allowed_shipping_methods', [])
        obj     = Category.objects.create(**validated_data)
        obj.allowed_shipping_methods.set(methods)
        return obj

    def update(self, instance, validated_data):
        if 'allowed_shipping_methods' in validated_data:
            instance.allowed_shipping_methods.set(
                validated_data.pop('allowed_shipping_methods')
            )
        return super().update(instance, validated_data)


class OrderSerializer(serializers.ModelSerializer):
    items           = OrderItemSerializer(many=True, read_only=True)
    updates         = OrderUpdateSerializer(many=True, read_only=True)
    payment         = OrderPaymentSerializer(read_only=True)
    shipping_method = ShippingMethodSerializer(read_only=True)
    shipping_address = AddressSerializer(read_only=True)

    class Meta:
        model  = Order
        fields = [
            'id', 'order_number', 'total_amount', 'status', 'payment_status',
            'shipping_address', 'shipping_method', 'tracking_number',
            'ordered_at', 'items', 'updates', 'payment',
        ]